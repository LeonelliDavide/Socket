﻿using System;
using System.Collections.Generic;
using System.Linq;
//librerie per lavorare con i soket e gli applicativi di rete
using System.Net;
using System.Net.Sockets;
//fine delle librerie per i soket
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Socket_4I
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        Socket socket = null; //creiamo un ptimo oggetto non ancora istanziato della classe per lavorare con i soket

        //per trasmettere c'è un bottone xaml
        //per poter ricevere e quindi leggere il buffer di ricezione c'è il seguente timer che ogni volta che scade vado a leggere il buffer e poi lo riavvio
        DispatcherTimer dTimer = null; //se nel buffer ci sono i dati allora vengono processati, se no aspetta ancora che finisca il timer per andare a leggere ancora
        
        
        //posso mettere un thread che legge costantemente il buffer (il thread ha la stessa porta del processo)
        public MainWindow()
        {
            InitializeComponent();

            //per creare l'oggetto bisogna passargli il tipo di indirizzo (ipv4), il tipo di soket (prevede ipv4) e il protocollo usato (udp)
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

            //definisco il mittente (che siamo noi) e gli imposto le informazioni del mio soket
            IPAddress local_address = IPAddress.Any; //recupera l'ip della mia macchina
            //creo l'oggetto con le informazioni per il soket con il mio pc che ho impostato la riga sopra e la porta scelta dall'utente
            IPEndPoint local_endpoint = new IPEndPoint(local_address, 50000); //imposto la porta di trasmissione (la 50000 in questo caso)
            //la porta è alta e quindi p di tipo private

            socket.Bind(local_endpoint);//assegna le info create prima al soket (creo il soket)

            //le 2 seguenti righe di codice posso anche cancellarle
            /*socket.Blocking = false;
            socket.EnableBroadcast = true;*/


            //creo il timer e gli dico che ogni volta che scade vado a fare quello che c'è dentro al metodo assegnato (aggiornamento_dTimer)
            dTimer = new DispatcherTimer();

            dTimer.Tick += new EventHandler(aggiornamento_dTimer); //imposto il metodo da guardare quando scade il timer
            dTimer.Interval = new TimeSpan(0, 0, 0, 0, 250); //imposto un tempo al timer (ogni 250 millisecondi)
            dTimer.Start(); //faccio partire il timer

        }

        //cosa faccio quando contrllo il buffer
        private void aggiornamento_dTimer(object sender, EventArgs e)
        {
            int nBytes = 0;

            //socket.Available va a vedere quanti byte sono presenti nel buffer (se ho almeno un byte)
            if ((nBytes = socket.Available) > 0)
            {
                //ricezione dei caratteri in attesa
                byte[] buffer = new byte[nBytes]; //creo un buffer di byte dove salvo i buffer che ho ricevuto e ha la stessa grandezza dei byte che ho ricevuto



                //vado a definire da chi ho ricevuto i dati

                //creo un oggetto che conterrà i dati 
                EndPoint remoreEndPoint = new IPEndPoint(IPAddress.Any, 0);

                //recessione dei dati e li porto da basso livello ad alto livello
                //prendo i dati che sono nel buffer nascosto li vado a mettere nel mio buffer di byte che ho creato in precedenza
                nBytes = socket.ReceiveFrom(buffer, ref remoreEndPoint);


                //vado a recuperare l'ip dell'utente che ha inviato i dati (solo l'ip in questo caso)
                string from = ((IPEndPoint)remoreEndPoint).Address.ToString();

                //codifico con UTF8 il contenuto del messaggio da byte a stringa
                //l'array buffer diventa un messaggio unico
                string messaggio = Encoding.UTF8.GetString(buffer, 0, nBytes);

                //aggiungo il contenuto alla lista
                lstMessaggi.Items.Add(from+": "+messaggio);

            }
        }

        //bottone per mandare il messaggio
        private void btnInvia_Click(object sender, RoutedEventArgs e)
        {
            //prendo l'ip a cui inviare e predispongo la porta di destinazione
            //(è come quando creo il mio soket con le mie informazioni, però qui sono le info del destinatario)
            IPAddress remote_address = IPAddress.Parse(txtTo.Text);//imposto l'ip da textbox

            IPEndPoint remote_endpoint = new IPEndPoint(remote_address, 60000);

            //codifico in byte il messaggio
            byte[] messaggio = Encoding.UTF8.GetBytes(txtMessaggio.Text);

            //invio in byte il messaggio al destinatario
            socket.SendTo(messaggio, remote_endpoint);
        }
    }
}
