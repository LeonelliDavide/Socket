﻿using System;
using System.Collections.Generic;
using System.Linq;
//librerie per lavorare con i soket e gli applicativi di rete
using System.Net;
using System.Net.Sockets;
//fine delle librerie per i soket
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Socket_4I
{
    public partial class MainWindow : Window
    {
        Socket socket = null; //creiamo un primo oggetto non ancora istanziato della classe per lavorare con i soket
        private Thread ThreadRecezione; //creo il thread che andrà a controllare il buffer
        private char[] Campo = { '1', '2', '3', '4', '5', '6', '7', '8', '9' }; //definisco il campo come un array di char perchè mi sarà più comodo confrontare le posizioni delle mosse in seguito senza dover fare tanti cast
        private char SegnoMio; //variabile che indica il mio segno
        private char SegnoAvversario; //variabile che indica il segno dell'avversario
        private bool Turno = false; //è il mio turno o no?
        private bool InizioGioco = false; //il gioco è iniziato?
        private IPEndPoint IpAvversario; //è l'ip dell'avversario
        private bool Connesso = false; //la connessione è stata stabilita?
        private int MiaPorta;
        private int AvversarioPorta;

        public MainWindow()
        {
            InitializeComponent();

            //quando viene avviato il programma va vedere le regole di come funziona questo programma (spiego in seguito nei commenti come mi è venuta l'idea di questo MessageBox)
            MessageBox.Show("Regole:\nLe regole sono come quelle di tris normale (se non le conosci vai su google, non ho voglia di scriverle).\nPer far partire una partita con qualcun'altro basta inserire l'ip della persona che si vuole sfidare nella barra in alto e premere il tasto di inizio.\nPuò capitare che qualcuno sfidi voi e allora la partita pertirà in automatico senza che voi facciate nulla (se non la vuoi giocare sei obbligato).\nQuando una partita finisce comparirà un tasto di restart di fianco a quello di inizio e cancellerà totalmente la partita giocata, una volta premuto è possibile far partire un altra partita\n(entrambi i giocatori devono avere premuto il pulsante per sfidare nuovamente la stessa persona).\nDurante il gioco c'è anche una chat che vi permetterà di scambiare i messaggi con il proprio avversario.\n\nN.B. Leggi bene queste regole perchè se non te le ricordi dovrai chiudere e riaprire questa applicazione.\nInoltre mi scuso se ci sono stati eventuali errori di battitura o di italiano.\n\n\nIL GIOCO INIZIERA' UNA VOLTA PREMUTO SU OK");
        }

        private void ImpostaIlSoket()
        {
            // creazione del socket UDP
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

            // impostazione dell'indirizzo locale su cui il socket sarà in ascolto
            IPAddress local_address = IPAddress.Any; //recupera l'ip della mia macchina
            IPEndPoint local_endpoint = new IPEndPoint(local_address, MiaPorta); //imposto la porta di trasmissione

            // associazione del socket alle informazioni appena create
            socket.Bind(local_endpoint);

            socket.Blocking = false;
            socket.EnableBroadcast = true;

            // creazione e avvio del thread che controllerà il buffer
            ThreadRecezione = new Thread(new ThreadStart(aggiornamento_dTimer));
            ThreadRecezione.IsBackground = true;
            ThreadRecezione.Start();
        }

        private void aggiornamento_dTimer()
        {
            while (true) // così controlla sempre
            {
                try
                {
                    int nBytes = 0;
                    // socket.Available va a vedere quanti byte sono presenti nel buffer (se ho almeno un byte)
                    if ((nBytes = socket.Available) > 0)
                    {
                        byte[] buffer = new byte[nBytes]; // buffer per memorizzare i dati ricevuti
                        EndPoint tempRemoteEndPoint = new IPEndPoint(IPAddress.Any, 0); // vado a definire da chi ho ricevuto i dati
                                                                                        // recessione dei dati e li porto da basso livello ad alto livello
                                                                                        // prendo i dati che sono nel buffer nascosto li vado a mettere nel mio buffer di byte che ho creato in precedenza
                        nBytes = socket.ReceiveFrom(buffer, ref tempRemoteEndPoint);
                        // codifico con UTF8 il contenuto del messaggio da byte a stringa
                        // l'array buffer diventa un messaggio unico
                        string messaggio = Encoding.UTF8.GetString(buffer, 0, nBytes);

                        // aggiorna la grafica dell'interfaccia utente con una lambda expression
                        Dispatcher.Invoke(() =>
                        {
                            // calcolo cosa vuol dire il messaggio che mi è arrivato
                            CalcoliDelMessaggioRicevuto(messaggio, (IPEndPoint)tempRemoteEndPoint);
                        });
                    }
                }
                catch (Exception){}
            }
        }


        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            if (!InizioGioco)
            {
                try
                {
                    AvversarioPorta = Convert.ToInt32(txtAvversarioPort.Text);
                    IPAddress remote_address = IPAddress.Parse(txtTo.Text); // indirizzo IP dell'avversario
                    SegnoMio = 'X'; // il giocatore corrente avrà come segno x
                    SegnoAvversario = 'O'; //l'avversario avrà come segno o
                    Turno = true; //dico che è il mio turno
                    InizioGioco = true; // dico che è iniziata la partita
                    Connesso = true; // dico che mi sono connesso con il mio avversario
                    IpAvversario = new IPEndPoint(remote_address, AvversarioPorta); // imposto la porta del mio avversario
                    InviaSegnaleDiInizio(remote_address.ToString()); // chiamo la funzione che creerà il messaggio di inizio partita da mandare all'altro programma per far si che solo uno dei programmi sfidi l'altro
                    //aggiornamento della grafica
                    txtSign.Text = ": X";
                    txtTurn.Text = "Tuo turno: si";
                    //questa cosa la avevo vista sul programma di monti e la volevo mettere anche io così la ho cercata
                    MessageBox.Show("Sei il giocatore 'X'."); //ti fa comparire una minipagina con scritto quello che voglio
                }
                catch (FormatException)
                {
                    MessageBox.Show("Indirizzo IP non valido."); //se c'è errore lo scrivo
                }
            }
        }

        //bottone che riazzera il tutto per far si che posso fare un altra partita senza dover chiudere e riaprire il programma
        private void btnRestart_Click(object sender, RoutedEventArgs e)
        {
            //resetto la grafica
            Array.Copy(new char[] { '1', '2', '3', '4', '5', '6', '7', '8', '9' }, Campo, 9);
            AggiornaCampo();
            txtSign.Text = "Segno:";
            txtTurn.Text = "Tuo turno:";
            lstMessaggi.Items.Clear(); // pulisce la lista dei messaggi
            InizioGioco = false; // imposta che il gioco non è iniziato
            Connesso = false; // imposta che non c'è connessione con un avversario
            Turno = false; // imposta che non è il turno del giocatore corrente
            MessageBox.Show("La partita è stata resettata."); // dico che il reset è avvenuto con successo
            btnRestart.Visibility = Visibility.Collapsed; //nascondo il bottone per il restart
        }

        //funzione che invia un messaggio per dire all'altro programma che vogliamo iniziare a giocare
        private void InviaSegnaleDiInizio(string ip)
        {
            // stabilisce la connessione con l'altro programma
            IPAddress remote_address = IPAddress.Parse(ip);
            IPEndPoint remote_endpoint = new IPEndPoint(remote_address, AvversarioPorta);

            //crea il messaggio e lo invia
            string messaggio = "START";
            byte[] data = Encoding.UTF8.GetBytes(messaggio); //codifico in byte il messaggio
            socket.SendTo(data, remote_endpoint); //invio in byte il messaggio al destinatario

        }

        //questo è il metodo che tutti i bottoni del campo da tris chiamano per far controllare e registrare la mossa
        private void Cell_Click(object sender, RoutedEventArgs e)
        {
            if (Turno) //controllo che sia il mio turno
            {
                Button clickedButton = (Button)sender; //identifico quale bottone ho premuto (ho dovuto cercare come fare perchè non volevo fare 9 metodi uguali)
                int position = int.Parse(clickedButton.Name.Substring(3)) - 1; // determina la posizione nel campo del bottone premuto togliendo le prime 3 lettere (perchè il bottone inizia con btn), poi converte il rimanente in un intero e gli toglie 1 perchè le posizioni del campo(che è un array) iniziano da zero

                // verifica che la posizione non sia già occupata
                if (Campo[position] != 'X' && Campo[position] != 'O')
                {
                    Campo[position] = SegnoMio; // assegna il simbolo del giocatore alla posizione selezionata dal pulsante
                    clickedButton.Content = SegnoMio.ToString(); // aggiorna il contenuto del pulsante
                    MandaMossa(position); // invia la mossa all'avversario tramite la funzione apposta
                    Turno = false; // cambia il turno
                    txtTurn.Text = "Tuo turno: no"; // aggiorna la grafica
                    if (ControllaVincitore() || ControllaPareggio()) // controlla se c'è un vincitore o un pareggio tramite le 2 funzioni apposite
                    {
                        Fine(); //se c'è stato un vincitore o un pareggio chiamo la funzione che indica la fine della partita
                    }
                }
                else
                {
                    MessageBox.Show("Mossa non valida."); //se la mossa non è valida la dico
                }
            }
            else
            {
                MessageBox.Show("Non è il tuo turno."); //se non è il tuo turno lo dico
            }
        }

        //funzione per mandare le mosse all'avversario
        private void MandaMossa(int position)
        {
            if (IpAvversario != null) //se esiste l'ip del mio avversario allora posso mandargli la mossa
            {
                // creo un messaggio per la mossa e per indicare che è una mossa metto MOVE: davanti e gli concateno la posizione del bottone premuto che gli avevo passato
                string messaggio = "MOVE:" + position;
                byte[] data = Encoding.UTF8.GetBytes(messaggio); //codifico in byte il messaggio
                socket.SendTo(data, IpAvversario); //invio in byte il messaggio al destinatario
            }
        }

        //questo è il bottone che serve per inviare i messaggi nella chat di gioco sotto al tris
        private void btnInvia_Click(object sender, RoutedEventArgs e)
        {
            if (IpAvversario != null) //controllo sempre che l'ip dell'avversario esista
            {
                // prendo il messaggio che l'utente ha inserito
                string messaggio = txtMessaggio.Text;
                // creo un messaggio e per indicare che è un messaggio metto CHAT: davanti (che ha la stessa lunghezza di MOVE: usato sopra) e gli concateno il messaggio dell'utente
                byte[] data = Encoding.UTF8.GetBytes("CHAT:" + messaggio);
                socket.SendTo(data, IpAvversario); //invio in byte il messaggio al destinatario


                // aggiunge il messaggio inviato alla lista dei messaggi e dato che è quello che ho inviato io lo metto a destra
                lstMessaggi.Items.Add(new ListBoxItem
                {
                    // tutta la grafica
                    Content = "Io: " + messaggio,
                    HorizontalAlignment = HorizontalAlignment.Right,
                    Background = Brushes.LightGray,
                    Padding = new Thickness(5),
                    Margin = new Thickness(5)
                });
                txtMessaggio.Clear(); // pulisce la casella di testo del messaggio
            }
        }

        //qui processo cosa vuol dire il messaggio che mi è arrivato
        private void CalcoliDelMessaggioRicevuto(string message, IPEndPoint remoteEndPoint)
        {
            if (message == "START") //se è un messaggio di inizio partita
            {
                if (!InizioGioco && !Connesso)
                {
                    SegnoMio = 'O'; // mi assegna il segno o perchè non sono stato io a far partire la partita
                    SegnoAvversario = 'X'; // assegna al mio avversario il segno x
                    Turno = false; // è il turno di chi inizia, quindi non tocca a me
                    InizioGioco = true; // dico che è iniziata la partita
                    Connesso = true; // indico che la connessione è stata stabilita
                    IpAvversario = remoteEndPoint; //vado a salvarmi l'ip del mio avversario
                    //aggiorno la grafica
                    txtSign.Text = "Segno: O";
                    txtTurn.Text = "Tuo turno: no";
                    txtTo.Text = remoteEndPoint.Address.ToString();
                    MessageBox.Show("Sei stato sfidato dal giocatore: " + remoteEndPoint.Address.ToString() + ".\nSei il giocatore 'O'."); //mando un messaggio che dice che uno mi ha sfidato e anche chi mi ha sfidato
                }
            }
            //il StartsWith mi va a controllare l'inizio della stringa se contiene le lettere che gli vado ad indicare (lo conosco perchè su js c'è una cosa simile startsWith())
            else if (message.StartsWith("MOVE:")) //se è una mossa
            {
                int posizioneMessaggio = Convert.ToInt32(message.Substring(5)); //estraggo la posizione dal messaggio che gli invio togliendoli le 5 posizioni iniziali di MOVE:

                if (posizioneMessaggio >= 0 && posizioneMessaggio < 9) //controlla che il messaggio contenga una posizione valida
                {
                    //aggiornamenti 
                    Campo[posizioneMessaggio] = SegnoAvversario;
                    AggiornaCampo(); //metodo per aggioranre la grafica del campo

                    //controlla se qualcuno ha vinto o c'è stato un pareggio
                    if (ControllaVincitore() || ControllaPareggio())
                    {
                        Fine(); //se la partita è finita chiama il metodo della fine
                    }
                    else
                    {
                        Turno = true; // cambia il turno
                        txtTurn.Text = "Tuo turno: si"; // aggiorna la grafica
                    }
                }
            }
            else if (message.StartsWith("CHAT:")) // se è un messaggio di chat
            {
                string chatMessage = message.Substring(5); //estraggo il messaggio dell'utente togliendo le prime 5 lettere CHAT:
                //aggiungo il messaggio e aggiorno la grafica
                lstMessaggi.Items.Add(new ListBoxItem
                {
                    //dato che il messaggio me lo ha mandato l'avversario lo metto a sinistra
                    Content = "Avversario: " + chatMessage,
                    HorizontalAlignment = HorizontalAlignment.Left,
                    Background = Brushes.LightGray,
                    Padding = new Thickness(5),
                    Margin = new Thickness(5)
                });
            }
        }

        //metodo per aggioranre la grafica del campo
        private void AggiornaCampo()
        {
            for (int i = 0; i < Campo.Length; i++)
            {
                Button button = (Button)FindName("btn" + (i + 1)); //trova un elemento con il nome indicato (anche questo lo ho dovuto cercare perchè non volevo fare un sacco di if)
                //aggiorno la grafica del bottone che ho trovato il nome se non è già stato occupato
                if (button != null)
                {
                    if (Campo[i] == 'X' || Campo[i] == 'O')
                    {
                        button.Content = Campo[i].ToString();
                    }
                    else
                    {
                        button.Content = "";
                    }
                }
            }
        }

        //metodo per controllare se c'è stato un vincitore
        private bool ControllaVincitore()
        {
            // essendo tris un gioco molto semplice ho pensato di vedere se ci sia stato un vincitore tramite 8 combinazioni vincenti
            string[] CombinazioniVincenti = { "012", "345", "678", "036", "147", "258", "048", "246" };
            foreach (var combinazione in CombinazioniVincenti) //controlla con un foreach se le combinazioni presenti adesso sul campo sono uguali ad almeno una delle combinazioni vincenti
            {
                if (Campo[combinazione[0] - '0'] == Campo[combinazione[1] - '0'] && Campo[combinazione[1] - '0'] == Campo[combinazione[2] - '0']) //controlla che i segni siano tutti uguali per far si che una combinazione sia valida per la vittoria
                {
                    MessageBox.Show("Il giocatore " + Campo[combinazione[0] - '0'] + " ha vinto!"); //se trova un vincitore dice quale segno ha vinto
                    return true;//se c'è stato un vincitore ritorna vero
                }
            }
            return false; //se nessuno ha vinto ritorna falso
        }

        //controlla se c'è stato un pareggio
        private bool ControllaPareggio()
        {
            // controlla se tutte le celle sono occupate
            foreach (var posto in Campo)
            {
                if (posto != 'X' && posto != 'O')
                {
                    return false; //se manca una cella allora non c'è stato nessun pareggio e quindi restituisco false
                }
            }
            MessageBox.Show("E' un pareggio!"); //se c'è stato un pareggio allora lo dico e ritorno vero
            return true;
            //da notare che tutte le volte che controllo se ci sia stato un vincitore o un pareggio metto sempre prima il vincitore e quindi se qualcuno ha vinto questa funzione non viene neanche chiamata e quindi uno può vincere anche con l'ultima mosse senza far comparire questo messaggio di pareggio perchè tutte le posizioni sono state riempite
        }

        //metodo che indica la fine della partita
        private void Fine()
        {
            btnRestart.Visibility = Visibility.Visible; // mostra il pulsante per il restart
        }

        //metodo che serve per settare la mia porta da grafica
        private void btnSetPorts_Click(object sender, RoutedEventArgs e)
        {
            MiaPorta = Convert.ToInt32(txtMiaPort.Text);
            MessageBox.Show("Porta settata, spera che anche il tuo avversario lo abbia fatto\nMia porta: " + MiaPorta);
            ImpostaIlSoket();
        }
    }
}